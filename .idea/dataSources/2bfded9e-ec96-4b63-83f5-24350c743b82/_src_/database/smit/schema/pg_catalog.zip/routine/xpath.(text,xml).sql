CREATE FUNCTION xpath (text, xml) RETURNS xml[]
	LANGUAGE sql
AS $$
select pg_catalog.xpath($1, $2, '{}'::pg_catalog.text[])
$$
