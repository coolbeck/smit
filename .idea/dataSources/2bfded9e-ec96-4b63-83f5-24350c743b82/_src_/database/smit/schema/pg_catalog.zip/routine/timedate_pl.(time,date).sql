CREATE FUNCTION timedate_pl (time without time zone, date) RETURNS timestamp without time zone
	LANGUAGE sql
AS $$
select ($2 + $1)
$$
